#ifndef _RLE_H
#define _RLE_H

	unsigned long rle_decode(register unsigned char *out, register unsigned char *in, register unsigned long len);
	
#endif
