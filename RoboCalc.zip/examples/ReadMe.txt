I think some of these may need fixing... for sure, the customen.89p program needs to be checked.
These programs will run on the TI-89, TI92p and V200.

robocalc.customen.89p	-	Setup the Custom Menu For Easy TI-Basic Programming with RoboCalc.

robocalc.circles.89p	-	Make the robot go in a circle.
robocalc.fig8.89p	-	Make the robot do a figure eight.
robocalc.hexbox.89p	-	Make the robot outline a hexagon.
robocalc.navbot.89p	-	Advanced navigation program; robot wanders about the room.
robocalc.zigzag.89p	-	Make the robot zigzag.
